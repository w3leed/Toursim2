package com.example.hassan.toursim.Places;

public class Model {
    String txt;
    String image;
    int price;

    public Model(String txt, String image,int price) {
        this.txt = txt;
        this.image = image;
        this.price=price;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getTxt() {
        return txt;
    }

    public void setTxt(String txt) {
        this.txt = txt;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
