package com.example.hassan.toursim;


import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

public class Main extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    public static final String TAG = MainActivity.class.getSimpleName();
    private ImageButton img_btn_side_menu;
    private DrawerLayout myDrawer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
      //  Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
      //  setSupportActionBar(toolbar);
        configureAllTripsButton();
        configureAllGovsButton();
        img_btn_side_menu = (ImageButton)findViewById(R.id.img_btn_side_menu);
        myDrawer = (DrawerLayout)findViewById(R.id.drawer_layout);
        img_btn_side_menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myDrawer.openDrawer(GravityCompat.START);

            }
        });
//        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
       /* fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });*/

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
      //  ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
      //          this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
  //      drawer.addDrawerListener(toggle);
   //     toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }



    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.itemCategories:
            //    Snackbar.make(getWindow().getDecorView().findViewById(android.R.id.content), "Test", Snackbar.LENGTH_LONG)
                //        .setAction("Action", null).show();
                Toast.makeText(this, "wwwwwwwwwwww", Toast.LENGTH_LONG).show();
                return true;
            case R.id.itemGovs:
                Snackbar.make(getWindow().getDecorView().findViewById(android.R.id.content), "Test", Snackbar.LENGTH_LONG)
                        .setAction("Ok", null).show();
                return true;
            case  R.id.itemCorporations:
                // do something
                return true;
            case R.id.itemTrips:
                // do something
                return true;
            case R.id.itemPlaces:
                // do something
                return true;
            case R.id.itemInterests:
                // do something
                return true;
            case R.id.itemSettings:
                // do something
                return true;
            case R.id.itemLogout:
                // do something
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    private void configureAllTripsButton() {

        Button btnAllTrips = (Button)findViewById(R.id.btnAllTrips);

        btnAllTrips.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              //  startActivity(new Intent(MainActivity.this, TripsActivity.class));
              //  finish();
                Toast.makeText(Main.this, "TripsActivity", Toast.LENGTH_SHORT).show();
            }
        });

    }
    private void configureAllGovsButton() {

        Button btnAllGovs= (Button)findViewById(R.id.btnAllGovs);

        btnAllGovs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //   startActivity(new Intent(TripsActivity.this, MainActivity.class));
                // finish();
                Toast.makeText(Main.this, "btnAllGovsWWWWW", Toast.LENGTH_LONG).show();
            }
        });

    }
}
