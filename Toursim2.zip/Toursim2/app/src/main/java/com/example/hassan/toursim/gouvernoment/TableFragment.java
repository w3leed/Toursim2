package com.example.hassan.toursim.gouvernoment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.Toast;

import com.example.hassan.toursim.ApiMange.ApiManager;
import com.example.hassan.toursim.Places.Governorate;
import com.example.hassan.toursim.Places.Model;
import com.example.hassan.toursim.R;
import com.example.hassan.toursim.Trip.PlacesAdapter;
import com.example.hassan.toursim.gouvernoment.GoAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by anupamchugh on 10/12/15.
 */
public class TableFragment extends Fragment {
    RecyclerView recyclerView;
    GoAdapter adapter;
    LinearLayoutManager linearLayoutManager;
    List<Model> data;


    public TableFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_table, container, false);
        recyclerView=rootView.findViewById(R.id.go_recycleview);
        getAllgo();

        return rootView;
    }


    public  void setData()
    {
        adapter=new GoAdapter(data);
        linearLayoutManager=new LinearLayoutManager(getContext());
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.addItemDecoration(new DividerItemDecoration(recyclerView.getContext(),DividerItemDecoration.VERTICAL));
        adapter.notifyDataSetChanged();

    }


    public void getAllgo()
    {
        if(GoAdapter.go_id!=null){
        ApiManager.getAPIs().GetAllGov("Bearer " + GoAdapter.go_id).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                data=new ArrayList<>();
                if (response.isSuccessful())
                {
                    JSONObject jsonObject = null;
                    try {
                        jsonObject = new JSONObject(response.body().string());
                        Log.e("jom", jsonObject.getJSONArray("data").toString());

                        JSONArray item = jsonObject.getJSONArray("data");
                        for (int i=0;i<item.length();i++)
                        {
                            JSONObject each_item = item.getJSONObject(i);
                            String name=each_item.getString("name");
                            String logo=each_item.getString("logo");
                            Log.e("noon",each_item.getString("name"));
                            data.add(new Model(name,logo,0));

                        }
                        setData();

                    } catch (JSONException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }



                }

            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Toast.makeText(getContext(),t.getMessage(),Toast.LENGTH_LONG).show();
            }
        });


    }
    else {

            ApiManager.getAPIs().GetAllGov("Bearer " + GoAdapter.token_go).enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    data=new ArrayList<>();
                    if (response.isSuccessful())
                    {
                        JSONObject jsonObject = null;
                        try {
                            jsonObject = new JSONObject(response.body().string());
                            Log.e("jom", jsonObject.getJSONArray("data").toString());

                            JSONArray item = jsonObject.getJSONArray("data");
                            for (int i=0;i<item.length();i++)
                            {
                                JSONObject each_item = item.getJSONObject(i);
                                String name=each_item.getString("name");
                                String logo=each_item.getString("logo");
                                Log.e("noon",each_item.getString("name"));
                                data.add(new Model(name,logo,0));

                            }
                            setData();

                        } catch (JSONException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }



                    }

                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    Toast.makeText(getContext(),t.getMessage(),Toast.LENGTH_LONG).show();
                }
            });


        }
    }



}
