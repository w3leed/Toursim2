package com.example.hassan.toursim.Places;

public class Token {

    String token;

    public String getToken() {
        return token;
    }

  public Token(String token) {
        this.token = token;

    }

    public Token() {

    }
}
